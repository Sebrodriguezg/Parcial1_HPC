      PROGRAM MORSE
C======================================================== gfortran -ffixed-form morse.f eigen.f -llapack -lblas -o morse
C     PROGRAMA PARA CALCULAR EL ESPECTRO DEL POTENCIAL
C     DE MORSE USANDO UNA BASE DEL OSCILADOR ARMONICO
C========================================================

      IMPLICIT DOUBLE PRECISION (A-H,O-Z)
      PARAMETER (N=80)

      DIMENSION X(N,N),X2(N,N)
      DIMENSION H(N,N)
      DIMENSION E(N),VP(N,N)
      DIMENSION ATILDE(N,N),B(N),Z(N)

C--------------------------------------------------------
C     PARAMETROS DEL POTENCIAL DE MORSE
C--------------------------------------------------------

      D=10.D0
      A=0.5D0

C--------------------------------------------------------
C     MATRIZ DEL OPERADOR X
C--------------------------------------------------------

      DO I=1,N
         DO J=1,N
            X(I,J)=0.D0
         END DO
      END DO

      DO I=1,N-1
         PP=FLOAT(I)
         X(I,I+1)=DSQRT(PP/2.D0)
         X(I+1,I)=X(I,I+1)
      END DO

C--------------------------------------------------------
C     MATRIZ X^2
C--------------------------------------------------------

      DO I=1,N
         DO J=1,N
            SUM=0.D0
            DO K=1,N
               SUM=SUM+X(I,K)*X(K,J)
            END DO
            X2(I,J)=SUM
         END DO
      END DO

C--------------------------------------------------------
C     HAMILTONIANO
C     H = P^2/2 + V(X)
C     APROXIMACION SIMPLE
C--------------------------------------------------------

      DO I=1,N
         DO J=1,N
            H(I,J)=0.D0
         END DO
      END DO

      DO I=1,N
         H(I,I)=FLOAT(I-1)+0.5D0
      END DO

C--------------------------------------------------------
C     POTENCIAL DE MORSE
C     V(x)=D(1-exp(-ax))^2
C--------------------------------------------------------

      DO I=1,N
         DO J=1,N
            H(I,J)=H(I,J)+D*(1.D0-DEXP(-A*X(I,J)))**2
         END DO
      END DO

C--------------------------------------------------------
C     DIAGONALIZACION
C--------------------------------------------------------

      CALL EIGEN(H,N,N,E,VP,ATILDE,B,Z)

C--------------------------------------------------------
C     AUTOVALORES
C--------------------------------------------------------

      WRITE(6,*) 'NIVELES DE ENERGIA'

      DO I=1,10
         WRITE(6,*) I,E(I)
      END DO

      END